MotifExtractor is a simple automated script for extracting the motifs of interest from biomolecule structure files. You may define one or more motifs to be extracted from a set of biomolecules stored in PDB format.

== Requirements ==
* Windows: .NET 4.5 or newer
* Linux and MacOS: MONO 3.2.3 or newer

== Input ==
* A folder with a set of biomolecules in PDB format.
* A .json file with settings, defining the motif(s) to be extracted. The key parameters of the .json file are encoded in attributes, 
  that you will need to edit depending on what you want to extract and from where:
  1. Location of the folder with biomolecules - attribute "InputFolders". When writing the path to your folder, note that backslashes 
     must be escaped (so C:\Data\pdb should be written as C:\\Data\\pdb), or forward slash can be used (C:/Data/pdb).
  2. Name of query residue - attributes "Id", "Name", and "Residues". Write the 3-letter code for the residue of interest.

== Output ==
A folder containing:
* Information about the progress of the computation (<code>log.txt</code>, <code>status.json</code>).
* ZIP file <code>result\motives.zip</code> containing:
  - A folder with motifs in PDB format (one for each motif specified in the input).
  - CSV files with detailed information about the found motifs.
* JSON file <code>result\summary.json</code> with the number of found motifs.

== Execution ==
* Windows
Open the utility cmd, go to the location where you unzipped MotifExtractor, and, after you have edited the .json file according to your 
needs, run MotifExtractor as "MotiveQuery.exe path_to_output motifs.json" (without the "). For example: 

  MotiveQuery c:\data\nag_motifs motifs.json

* Linux and MacOS
Open a terminal, go to the location where you unzipped MotifExtractor, and, after you have edited the .json file according to your needs, 
run MotifExtractor as "mono MotiveQuery.exe path_to_output motifs.json" (without the ").
